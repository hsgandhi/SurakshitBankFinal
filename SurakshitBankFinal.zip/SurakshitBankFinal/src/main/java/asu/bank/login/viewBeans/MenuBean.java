package asu.bank.login.viewBeans;

public class MenuBean {
	
	private String viewText;
	private String actionValue;
	
	public String getViewText() {
		return viewText;
	}
	public void setViewText(String viewText) {
		this.viewText = viewText;
	}
	public String getActionValue() {
		return actionValue;
	}
	public void setActionValue(String actionValue) {
		this.actionValue = actionValue;
	}

}
